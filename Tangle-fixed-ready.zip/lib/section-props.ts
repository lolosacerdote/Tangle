// lib/section-props.ts
export type SectionProps = { currentGroupId?: string | null };
